import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('game_rooms', {
 code: text('code').primaryKey(),
 createKey: text('create_key').notNull().unique(),
 version: integer('version').notNull().default(0),
 payload: text('payload').notNull(),
 updatedAt: integer('updated_at').notNull(),
 expiresAt: integer('expires_at').notNull(),
}, t => [index('idx_rooms_expires').on(t.expiresAt)]);
export const limits = sqliteTable('request_limits', {
 key: text('key').primaryKey(),
 hits: integer('hits').notNull().default(0),
 expiresAt: integer('expires_at').notNull(),
}, t => [index('idx_limits_expires').on(t.expiresAt)]);
