import { GameError, newRoom, viewRoom, findMember, joinRoom, applyAction, randomInt } from './game.js';
import { assets } from './assets.js';
const TTL=24*60*60*1000;
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const hash=async text=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))).map(v=>v.toString(16).padStart(2,'0')).join('');
function dbFor(env){if(!env.DB)throw new GameError('房间服务暂时不可用，请稍后再试。',503);return env.DB;}
async function identity(req){const m=req.headers.get('Authorization')?.match(/^Bearer ([a-f0-9]{64})$/);if(!m)throw new GameError('身份已失效，请重新打开网页。',401);return hash(m[1]);}
async function body(req){if(Number(req.headers.get('Content-Length')||0)>8192)throw new GameError('请求内容过长。',413);const text=await req.text();if(text.length>8192)throw new GameError('请求内容过长。',413);try{const x=JSON.parse(text);if(!x||typeof x!=='object'||Array.isArray(x))throw 0;return x;}catch{throw new GameError('请求内容不正确。');}}
async function limit(db,key,max,windowMs){const now=Date.now(),bucket=Math.floor(now/windowMs),k=key+':'+bucket;const row=await db.prepare('INSERT INTO request_limits (key,hits,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET hits=hits+1 RETURNING hits').bind(k,now+windowMs).first();if(row.hits>max)throw new GameError('操作太快，请稍等一会儿再试。',429);}
async function readRoom(db,code){const row=await db.prepare('SELECT code,version,payload,expires_at FROM game_rooms WHERE code=?').bind(code).first();if(!row||row.expires_at<Date.now())throw new GameError('房间不存在或已过期，请核对房间号。',404);return row;}
async function mutate(db,code,change){for(let i=0;i<7;i++){const row=await readRoom(db,code),room=JSON.parse(row.payload);const changed=change(room);if(changed===false)return row;const payload=JSON.stringify(room),now=Date.now();const result=await db.prepare('UPDATE game_rooms SET payload=?,version=version+1,updated_at=?,expires_at=? WHERE code=? AND version=?').bind(payload,now,now+TTL,code,row.version).run();if(result.meta.changes===1)return {...row,payload,version:row.version+1};}throw new GameError('房间正在同步，请稍后再操作。',409);}
async function createRoom(db,user,input){
 if(typeof input.requestId!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(input.requestId))throw new GameError('请求编号无效。');
 const createKey=await hash(user+':'+input.requestId);
 const existing=await db.prepare('SELECT code,version,payload,expires_at FROM game_rooms WHERE create_key=?').bind(createKey).first();if(existing&&existing.expires_at>Date.now())return existing;
 const room=newRoom(input.name,user),chars='23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
 for(let i=0;i<5;i++){
  const code=Array.from({length:8},()=>chars[randomInt(chars.length)]).join(''),now=Date.now();
  const result=await db.prepare('INSERT OR IGNORE INTO game_rooms (code,create_key,version,payload,updated_at,expires_at) VALUES (?,?,0,?,?,?)').bind(code,createKey,JSON.stringify(room),now,now+TTL).run();
  if(result.meta.changes===1)return {code,version:0,payload:JSON.stringify(room)};
  const duplicate=await db.prepare('SELECT code,version,payload,expires_at FROM game_rooms WHERE create_key=?').bind(createKey).first();if(duplicate&&duplicate.expires_at>Date.now())return duplicate;
 }
 throw new GameError('暂时无法创建房间，请重试。',503);
}
export default {async fetch(request,env,ctx){
 const url=new URL(request.url);
 try{
  if(!url.pathname.startsWith('/api/')){
   const asset=assets[url.pathname==='/'?'/index.html':url.pathname];if(!asset)return new Response('Not found',{status:404});
   if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
   return new Response(request.method==='HEAD'?null:asset.body,{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'"}});
  }
  if(request.headers.get('Origin')&&request.headers.get('Origin')!==url.origin)throw new GameError('请从网站页面进行操作。',403);
  if(request.method==='GET'&&url.pathname==='/api/session'){
   const token=Array.from(crypto.getRandomValues(new Uint8Array(32))).map(x=>x.toString(16).padStart(2,'0')).join('');return json({token});
  }
  const db=dbFor(env),user=await identity(request);
  if(request.method==='POST'&&url.pathname==='/api/rooms'){
   await limit(db,'create:'+user,8,3600000);
   const ip=request.headers.get('CF-Connecting-IP');if(ip)await limit(db,'create-ip:'+await hash(ip),25,3600000);
   const row=await createRoom(db,user,await body(request));
   ctx?.waitUntil?.(db.batch([db.prepare('DELETE FROM game_rooms WHERE code IN (SELECT code FROM game_rooms WHERE expires_at<? LIMIT 50)').bind(Date.now()),db.prepare('DELETE FROM request_limits WHERE key IN (SELECT key FROM request_limits WHERE expires_at<? LIMIT 100)').bind(Date.now())]).catch(()=>{}));
   return json(viewRoom(row,user),201);
  }
  const match=url.pathname.match(/^\/api\/rooms\/([23456789A-HJ-NP-Z]{8})(?:\/(join|action))?$/);if(!match)throw new GameError('没有这个页面。',404);const [,code,operation]=match;
  if(request.method==='GET'&&!operation){
   let row=await readRoom(db,code),room=JSON.parse(row.payload),p=findMember(room,user);if(!p)throw new GameError('请填写昵称加入这个房间。',403);
   if(Date.now()-p.lastSeen>18000&&room.phase!=='closed')row=await mutate(db,code,r=>{const member=findMember(r,user);if(!member)throw new GameError('你已离开这个房间。',403);if(Date.now()-member.lastSeen<=18000)return false;member.lastSeen=Date.now();});
   return json(viewRoom(row,user));
  }
  if(request.method==='POST'&&operation==='join'){
   await limit(db,'join:'+user,20,60000);const ip=request.headers.get('CF-Connecting-IP');if(ip)await limit(db,'join-ip:'+await hash(ip),90,60000);
   const input=await body(request),row=await mutate(db,code,r=>joinRoom(r,user,input.name));return json(viewRoom(row,user));
  }
  if(request.method==='POST'&&operation==='action'){
   await limit(db,'action:'+user,100,60000);const input=await body(request);const row=await mutate(db,code,r=>applyAction(r,user,input));return json(input.action==='leave'?{left:true}:viewRoom(row,user));
  }
  throw new GameError('不支持这个操作。',405);
 }catch(error){if(error instanceof GameError)return json({error:error.message},error.status);console.error('Night Deck request failed',error?.name,error?.message);return json({error:'房间服务暂时不可用，请稍后重试。'},503);}
}};
