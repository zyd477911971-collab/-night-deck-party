import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import worker from '../dist/server/index.js';
import {CARDS} from '../server/cards.js';
import {newRoom,joinRoom,applyAction,viewRoom} from '../server/game.js';
const sqlite=new DatabaseSync(':memory:');sqlite.exec(readFileSync('drizzle/0000_mysterious_tenebrous.sql','utf8'));sqlite.exec('PRAGMA optimize');
const DB={prepare(sql){return {args:[],bind(...args){this.args=args;return this;},async first(){await Promise.resolve();return sqlite.prepare(sql).get(...this.args)||null;},async run(){await Promise.resolve();const result=sqlite.prepare(sql).run(...this.args);return {meta:{changes:Number(result.changes)}};}};},async batch(items){return Promise.all(items.map(x=>x.run()));}};
const env={DB},ctx={waitUntil(p){p.catch(()=>{});}},origin='https://nightdeck.test';
async function request(token,path,body){const response=await worker.fetch(new Request(origin+path,{method:body?'POST':'GET',headers:{...(token?{Authorization:'Bearer '+token}:{}),...(body?{'Content-Type':'application/json',Origin:origin}:{})},body:body?JSON.stringify(body):undefined}),env,ctx);return {status:response.status,data:await response.json()};}
const clients=[];for(let i=0;i<6;i++)clients.push((await request(null,'/api/session')).data.token);
const createPayload={name:'房主',requestId:crypto.randomUUID()};let a=await request(clients[0],'/api/rooms',createPayload);assert.equal(a.status,201);let view=a.data;const code=view.code;
assert.equal((await request(clients[0],'/api/rooms',createPayload)).data.code,code,'Create retry must return same room');
await Promise.all(clients.slice(1,5).map((token,i)=>request(token,'/api/rooms/'+code+'/join',{name:'玩家'+(i+2)}).then(r=>assert.equal(r.status,200))));
assert.equal((await request(clients[5],'/api/rooms/'+code+'/join',{name:'第六人'})).status,409,'Capacity enforced');
assert.equal((await request(clients[5],'/api/rooms/'+code)).status,403,'Non-member cannot read state');
const get=i=>request(clients[i],'/api/rooms/'+code).then(r=>{assert.equal(r.status,200);return r.data;});
const send=async(i,action,extra={},fixed)=>{const v=await get(i);return request(clients[i],'/api/rooms/'+code+'/action',fixed||{action,roundId:v.roundId,turnId:v.turnId,requestId:crypto.randomUUID(),...extra});};
assert.equal((await send(1,'start')).status,403,'Only host starts');assert.equal((await send(0,'start')).status,200);
const views=await Promise.all([0,1,2,3,4].map(get));const indexFor=id=>views.findIndex(v=>v.me===id);
assert.equal((await send(1,'draw')).status,403,'Wrong player cannot draw');
view=await get(0);const drawPayload={action:'draw',roundId:view.roundId,turnId:view.turnId,requestId:crypto.randomUUID()};
const simultaneous=await Promise.all([request(clients[0],'/api/rooms/'+code+'/action',drawPayload),request(clients[0],'/api/rooms/'+code+'/action',drawPayload),request(clients[0],'/api/rooms/'+code+'/action',{...drawPayload,requestId:crypto.randomUUID()})]);
assert.equal((await get(0)).remaining,83,'Concurrent requests draw exactly one card');assert.equal(simultaneous.filter(r=>r.status===200).length,2,'Same request retries are idempotent');
const cardsSeen=new Set(),counts={};let didFull=false,didPrivate=false,didUse=false;
for(let n=0;n<84;n++){
 let v=await get(0),i=indexFor(v.turnPlayerId);if(n){const r=await send(i,'draw');assert.equal(r.status,200,r.data.error);v=r.data;}const card=v.current;
 assert(!cardsSeen.has(card.id),'No physical copy is drawn twice');cardsSeen.add(card.id);counts[card.title]=(counts[card.title]||0)+1;
 const own=await get(i);
 if(card.isPublicRole){const all=await Promise.all([0,1,2,3,4].map(get));assert(all.every(x=>x.publicRole?.id===card.id&&x.publicRole.ownerId===v.turnPlayerId));assert(!own.held.some(x=>x.id===card.id));assert.equal((await send(i,'hold')).status,409);assert.equal((await send(i,'discard',{cardId:card.id})).status,409);}
 else if(card.isFunction){const r=await send(i,'hold');if(own.held.length<2){assert.equal(r.status,200,r.data.error);assert.equal((await send(i,'hold')).status,409,'No duplicate hold');const mine=await get(i),other=await get((i+1)%5);assert(mine.held.some(c=>c.id===card.id));assert(!other.held.some(c=>c.id===card.id));assert(!JSON.stringify(other.players).includes('rule'));assert(!JSON.stringify(other).includes('"hash"'));assert(!JSON.stringify(other).includes('"requests"'));assert.equal((await send((i+1)%5,'use',{cardId:card.id})).status,403,'Cannot use another hand');didPrivate=true;}
 else{assert.equal(r.status,409,'Two-card limit is enforced');didFull=true;if(!didUse){const held=own.held[0];assert.equal((await send(i,'use',{cardId:held.id})).status,200);assert.equal((await send(i,'hold')).status,200);assert.equal((await send(i,'use',{cardId:held.id})).status,403,'Used card is gone');didUse=true;}}
 }else assert.equal((await send(i,'hold')).status,409,'Only function cards can be held');
 if(n%10===0){const all=await Promise.all([0,1,2,3,4].map(get));assert(all.every(x=>x.current.id===card.id&&x.remaining===83-n),'All clients see same table');}
 assert.equal((await send(i,'finish')).status,200);
}
assert(didFull&&didPrivate&&didUse);assert.equal(cardsSeen.size,84);const expected={};for(const c of CARDS)expected[c.title]=(expected[c.title]||0)+1;assert.deepEqual(counts,expected);assert.equal((await get(0)).phase,'finished');
assert.equal((await send(1,'reset')).status,403);const before=(await get(0)).roundId;assert.equal((await send(0,'reset')).status,200);const reset=await get(0);assert.equal(reset.remaining,84);assert.equal(reset.publicRole,null);assert.notEqual(reset.roundId,before);for(let i=0;i<5;i++)assert.equal((await get(i)).held.length,0);
assert.equal((await request(clients[0],'/api/rooms/'+code+'/action',drawPayload)).status,409,'Old round request cannot draw');
const reconnect=await get(2);assert.equal(reconnect.me,views[2].me,'Token restores same identity');assert.equal((await request(clients[2],'/api/rooms/'+code+'/join',{name:'其他名字'})).data.me,views[2].me,'Join retry does not duplicate player');
assert.equal((await send(0,'close')).status,200);assert.equal((await send(1,'draw')).status,410);const v=await get(1),leave={action:'leave',roundId:v.roundId,turnId:v.turnId,requestId:crypto.randomUUID()};assert.equal((await request(clients[1],'/api/rooms/'+code+'/action',leave)).data.left,true);assert.equal((await request(clients[1],'/api/rooms/'+code+'/action',leave)).data.left,true,'Leave retry is idempotent');
const html=await worker.fetch(new Request(origin+'/'),env,ctx);assert.equal(html.status,200);assert((await html.text()).includes('room-code-input'));assert.equal((await worker.fetch(new Request(origin+'/server/cards.js'),env,ctx)).status,404);
// Separate lifecycle scenario: host handoff, paused table, returning player.
const two=await request(clients[0],'/api/rooms',{name:'房主',requestId:crypto.randomUUID()});const code2=two.data.code;
await request(clients[1],'/api/rooms/'+code2+'/join',{name:'朋友'});
async function action2(i,action,extra={}){const v=(await request(clients[i],'/api/rooms/'+code2)).data;return request(clients[i],'/api/rooms/'+code2+'/action',{action,requestId:crypto.randomUUID(),roundId:v.roundId,turnId:v.turnId,...extra});}
assert.equal((await action2(0,'start')).status,200);assert.equal((await action2(0,'leave')).data.left,true);
let returned=(await request(clients[1],'/api/rooms/'+code2)).data;assert.equal(returned.phase,'paused');assert.equal(returned.hostId,returned.me);
returned=(await request(clients[0],'/api/rooms/'+code2+'/join',{name:'回来了'})).data;assert.equal(returned.phase,'playing');
assert.equal((await action2(0,'reset')).status,403,'Returning former host cannot reclaim host powers');assert.equal((await action2(1,'advance')).status,200);
const resumed=(await request(clients[0],'/api/rooms/'+code2)).data;assert.equal(resumed.turnPlayerId,resumed.me);
const crossOrigin=await worker.fetch(new Request(origin+'/api/rooms',{method:'POST',headers:{Origin:'https://unrelated.test',Authorization:'Bearer '+clients[0]},body:'{}'}),env,ctx);assert.equal(crossOrigin.status,403);
console.log('PASS: real SQLite migrations; five independent clients; capacity; atomic concurrent draws; retry idempotency; full 84-card deck; personal hand isolation; two-card limit; host authority; reset; reconnect; close and leave.');

// Identity remains public even with a full ordinary hand and across intervening turns.
const roleRoom=newRoom('甲','a');joinRoom(roleRoom,'b','乙');
const act=(hash,action,extra={})=>applyAction(roleRoom,hash,{action,requestId:crypto.randomUUID(),roundId:roleRoom.roundId,turnId:roleRoom.turnId,...extra});
const inspect=hash=>viewRoom({code:'TESTROOM',version:1,payload:roleRoom},hash);
const identities=CARDS.filter(c=>c.typeId==='custom-1');
const ordinary=CARDS.filter(c=>c.isFunction&&c.typeId!=='custom-1').slice(0,2);
roleRoom.players[0].held=ordinary.map(c=>c.id);
roleRoom.remaining=[identities[2].id,identities[1].id,CARDS[0].id,identities[0].id];
act('a','start');act('a','draw');
assert.equal(inspect('a').held.length,2,'Automatic role does not evict a full hand');
assert.equal(inspect('b').publicRole.ownerId,roleRoom.players[0].id);
const firstRole=inspect('a').publicRole.id;
act('a','finish');act('b','draw');assert.equal(inspect('b').publicRole.id,firstRole,'Ordinary draw preserves identity');act('b','finish');
act('a','draw');assert.equal(inspect('b').publicRole.id,identities[1].id,'Same owner receives only the latest copy');act('a','finish');
act('b','draw');assert.equal(inspect('a').publicRole.ownerId,roleRoom.players[1].id,'Next identity transfers to new owner');
assert.throws(()=>act('b','use',{cardId:identities[2].id}),/不能手动移除/);
assert.throws(()=>act('a','discard',{cardId:identities[0].id}),/不能手动移除/);
assert.equal(inspect('a').held.length,2);assert.equal(inspect('b').held.length,0);
act('b','leave');assert.equal(inspect('a').publicRole.ownerActive,false,'Leaving does not transfer identity early');
act('a','reset');assert.equal(inspect('a').publicRole,null);
console.log('PASS: automatic public identity; full hand; persistence; same-owner replacement; new-owner transfer; no manual removal; reset.');
