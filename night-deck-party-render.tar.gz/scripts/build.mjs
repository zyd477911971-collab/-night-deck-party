import {mkdirSync,readFileSync,writeFileSync,copyFileSync,rmSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
rmSync('dist',{recursive:true,force:true});mkdirSync('dist/server',{recursive:true});mkdirSync('dist/.openai',{recursive:true});
for(const file of ['index.js','game.js','cards.js'])copyFileSync('server/'+file,'dist/server/'+file);
const assets={};for(const [name,type] of [['index.html','text/html; charset=utf-8'],['app.js','text/javascript; charset=utf-8'],['style.css','text/css; charset=utf-8']])assets['/'+name]={body:readFileSync('public/'+name,'utf8'),type};
writeFileSync('dist/server/assets.js','export const assets = '+JSON.stringify(assets)+';\n');copyFileSync('.openai/hosting.json','dist/.openai/hosting.json');
const worker=await import(pathToFileURL(process.cwd()+'/dist/server/index.js'));if(typeof worker.default?.fetch!=='function')throw new Error('Invalid Worker export');
console.log('Worker and embedded assets built successfully.');
