import { CARDS } from './cards.js';

export class GameError extends Error {
  constructor(message,status=400){super(message);this.status=status;}
}
export const MAX_PLAYERS=5;
const byId=new Map(CARDS.map(c=>[c.id,c]));
export function cardView(id){const c=byId.get(id);return c?{id:c.id,title:c.title,rule:c.rule,isFunction:c.isFunction,isPublicRole:c.typeId==='custom-1'}:null;}
export function randomInt(n){const values=new Uint32Array(1),limit=Math.floor(2**32/n)*n;do{crypto.getRandomValues(values);}while(values[0]>=limit);return values[0]%n;}
export function shuffledDeck(){const ids=CARDS.map(c=>c.id);for(let i=ids.length-1;i>0;i--){const j=randomInt(i+1);[ids[i],ids[j]]=[ids[j],ids[i]];}return ids;}
export function cleanName(name){if(typeof name!=='string')throw new GameError('请填写昵称。');const n=name.trim().replace(/[\u0000-\u001f\u007f]/g,'');if(!n||[...n].length>12)throw new GameError('昵称需要 1–12 个字。');return n;}
export function newPlayer(name,hash,now){return {id:crypto.randomUUID(),name:cleanName(name),hash,held:[],active:true,lastSeen:now};}
export function log(room,message){room.events.push({id:crypto.randomUUID(),message,at:Date.now()});room.events=room.events.slice(-8);}
export function newRoom(name,hash,now=Date.now()){
 const p=newPlayer(name,hash,now);return {hostId:p.id,players:[p],phase:'lobby',roundId:crypto.randomUUID(),round:1,turnId:crypto.randomUUID(),turnPlayerId:p.id,remaining:shuffledDeck(),current:null,previous:null,publicRole:null,events:[{id:crypto.randomUUID(),message:p.name+' 创建了房间',at:now}],requests:[]};
}
function ensurePublicRole(r){
 // Upgrade already-open rooms, preserving a visible or held identity card.
 if(!Object.hasOwn(r,'publicRole')){
  const current=byId.get(r.current?.cardId)?.typeId==='custom-1'?r.current:null;
  const held=r.players.flatMap(p=>p.held.filter(id=>byId.get(id)?.typeId==='custom-1').map(cardId=>({cardId,ownerId:p.id})));
  r.publicRole=current?{cardId:current.cardId,ownerId:current.ownerId}:held.at(-1)||null;
 }
 for(const p of r.players)p.held=p.held.filter(id=>byId.get(id)?.typeId!=='custom-1');
 if(r.current&&byId.get(r.current.cardId)?.typeId==='custom-1')r.current.held=true;
}
export function findMember(room,hash){return room.players.find(p=>p.hash===hash&&p.active);}
export function viewRoom(row,hash,now=Date.now()){
 const r=typeof row.payload==='string'?JSON.parse(row.payload):row.payload,p=findMember(r,hash);
 if(!p)throw new GameError('你还没有加入这个房间，请填写昵称加入。',403);
 ensurePublicRole(r);
 return {code:row.code,version:row.version,phase:r.phase,round:r.round,roundId:r.roundId,turnId:r.turnId,turnPlayerId:r.turnPlayerId,hostId:r.hostId,me:p.id,remaining:r.remaining.length,total:CARDS.length,
 players:r.players.filter(x=>x.active).map(x=>({id:x.id,name:x.name,heldCount:x.held.length,online:now-x.lastSeen<45000})),
 publicRole:r.publicRole?{...cardView(r.publicRole.cardId),ownerId:r.publicRole.ownerId,ownerName:r.players.find(x=>x.id===r.publicRole.ownerId)?.name||'玩家',ownerActive:!!r.players.find(x=>x.id===r.publicRole.ownerId)?.active}:null,
 held:p.held.map(cardView),current:r.current?{...cardView(r.current.cardId),ownerId:r.current.ownerId,ownerName:r.players.find(x=>x.id===r.current.ownerId)?.name||'玩家',held:r.current.held,awaiting:r.current.awaiting}:null,
 previous:r.previous?cardView(r.previous):null,events:r.events};
}
function requireHost(r,p){if(r.hostId!==p.id)throw new GameError('只有房主可以进行此操作。',403);}
function requireTurn(r,p,input){if(r.phase!=='playing')throw new GameError('牌局还未开始或已经结束。',409);if(r.turnPlayerId!==p.id)throw new GameError('还没有轮到你抽牌。',403);if(input.turnId!==r.turnId)throw new GameError('回合已更新，请重试。',409);}
function advance(r){
 const active=r.players.filter(p=>p.active);const index=active.findIndex(p=>p.id===r.turnPlayerId);
 if(r.current)r.current.awaiting=false;
 r.turnPlayerId=active.length?active[(index+1)%active.length].id:null;r.turnId=crypto.randomUUID();
 if(!r.remaining.length)r.phase='finished';
 if(active.length<2&&r.phase==='playing')r.phase='paused';
}
export function joinRoom(r,hash,name,now=Date.now()){
 if(r.phase==='closed')throw new GameError('房间已结束，请创建新房间。',410);
 let p=r.players.find(x=>x.hash===hash);
 if(p?.active){p.lastSeen=now;return;}
 if(r.players.filter(x=>x.active).length>=MAX_PLAYERS)throw new GameError('房间已满，最多 5 人。',409);
 const n=cleanName(name);if(r.players.some(x=>x.active&&x.name===n))throw new GameError('这个昵称已有人使用，换一个吧。',409);
 if(p){p.name=n;p.active=true;p.lastSeen=now;p.held=[];}else{if(r.players.length>=30)throw new GameError('本房间加入次数已满，请创建新房间。');p=newPlayer(n,hash,now);r.players.push(p);}
 if(r.phase==='paused'&&r.players.filter(x=>x.active).length>=2){r.phase='playing';if(!r.players.some(x=>x.id===r.turnPlayerId&&x.active))r.turnPlayerId=p.id;}
 log(r,p.name+' 加入了房间');
}
export function applyAction(r,hash,input,now=Date.now()){
 const known=r.players.find(x=>x.hash===hash);
 const repeated=r.requests.find(x=>x.id===input.requestId&&x.playerId===known?.id);
 if(repeated){if(repeated.action!==input.action)throw new GameError('请求编号已使用。',409);return false;}
 const p=findMember(r,hash);if(!p)throw new GameError('你不在这个房间中。',403);
 if(r.phase==='closed'&&input.action!=='leave')throw new GameError('房间已结束。',410);
 if(typeof input.requestId!=='string'||!/^[a-zA-Z0-9-]{16,80}$/.test(input.requestId))throw new GameError('请求编号无效，请刷新重试。');
 if(input.roundId!==r.roundId)throw new GameError('牌局已重新开始，请等待同步后再操作。',409);
 p.lastSeen=now;ensurePublicRole(r);
 switch(input.action){
  case 'start':
   requireHost(r,p);if(r.phase!=='lobby')throw new GameError('牌局已开始。',409);
   if(r.players.filter(x=>x.active).length<2)throw new GameError('至少需要两位玩家加入。');
   r.phase='playing';r.turnPlayerId=r.players.find(x=>x.active).id;r.turnId=crypto.randomUUID();log(r,'房主开始了牌局');break;
  case 'draw':
   requireTurn(r,p,input);if(r.current?.awaiting)throw new GameError('先完成当前这张牌。',409);
   if(!r.remaining.length)throw new GameError('牌已抽完，请房主重新洗牌。',409);
   r.previous=r.current?.cardId||null;r.current={cardId:r.remaining.pop(),ownerId:p.id,held:false,awaiting:true};if(byId.get(r.current.cardId).typeId==='custom-1'){r.publicRole={cardId:r.current.cardId,ownerId:p.id};r.current.held=true;}log(r,p.name+' 抽到了「'+byId.get(r.current.cardId).title+'」');break;
  case 'hold':
   if(byId.get(r.current?.cardId)?.typeId==='custom-1')throw new GameError('身份牌已自动公开保留，下一张出现时自动替换。',409);
   requireTurn(r,p,input);if(!r.current?.awaiting||r.current.ownerId!==p.id||!byId.get(r.current.cardId)?.isFunction)throw new GameError('只能保留自己本回合抽到的功能牌。',409);
   if(r.current.held)throw new GameError('这张牌已经保留。',409);if(p.held.length>=2)throw new GameError('最多保留 2 张，请先使用或弃掉一张。',409);
   p.held.push(r.current.cardId);r.current.held=true;log(r,p.name+' 保留了一张功能牌');break;
  case 'finish':
   requireTurn(r,p,input);if(!r.current?.awaiting)throw new GameError('请先抽一张牌。',409);advance(r);break;
  case 'use':case 'discard':{
   if(byId.get(input.cardId)?.typeId==='custom-1')throw new GameError('身份牌不能手动移除，下一张出现时自动替换。',409);
   const i=p.held.indexOf(input.cardId);if(i<0)throw new GameError('你的保留区没有这张牌。',403);
   const id=p.held.splice(i,1)[0];log(r,p.name+(input.action==='use'?' 使用了「'+byId.get(id).title+'」':' 弃掉了一张功能牌'));break;}
  case 'advance':
   requireHost(r,p);if(r.phase!=='playing'||input.turnId!==r.turnId)throw new GameError('回合已变化，请重试。',409);log(r,'房主结束了当前回合');advance(r);break;
  case 'reset':
   requireHost(r,p);r.remaining=shuffledDeck();r.current=null;r.previous=null;r.publicRole=null;r.round++;r.roundId=crypto.randomUUID();r.turnId=crypto.randomUUID();r.turnPlayerId=r.players.find(x=>x.active).id;r.phase='lobby';for(const x of r.players)x.held=[];r.requests=[];log(r,'房主重新洗牌，等待开始');break;
  case 'close':requireHost(r,p);r.phase='closed';log(r,'房主结束了房间');break;
  case 'leave':{
   p.active=false;p.held=[];const a=r.players.filter(x=>x.active);
   if(!a.length)r.phase='closed';else{
    if(r.hostId===p.id)r.hostId=a[0].id;
    if(r.turnPlayerId===p.id){if(r.current)r.current.awaiting=false;const at=r.players.indexOf(p);r.turnPlayerId=r.players.slice(at+1).find(x=>x.active)?.id||a[0].id;r.turnId=crypto.randomUUID();}
    if(a.length<2&&r.phase==='playing')r.phase='paused';
   }log(r,p.name+' 离开了房间');break;}
  default:throw new GameError('不支持这个操作。');
 }
 r.requests.push({id:input.requestId,playerId:p.id,action:input.action});r.requests=r.requests.slice(-128);return true;
}
