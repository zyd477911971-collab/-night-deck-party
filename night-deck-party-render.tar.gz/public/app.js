'use strict';
const $=id=>document.getElementById(id);
let token='',room=null,busy=false,connected=false,polling=false,timer=null,lastSignature='',pendingConfirm=null,storageOK=true,lastActionError=null,accessStopped=null;
const store={get(key){try{return localStorage.getItem('nd.'+key);}catch{storageOK=false;return null;}},set(key,value){try{localStorage.setItem('nd.'+key,value);}catch{storageOK=false;}},remove(key){try{localStorage.removeItem('nd.'+key);}catch{}}};
function notice(message,error=false){$('notice').hidden=!message;$('notice').textContent=message;$('notice').dataset.error=String(error);}
function status(ok,label){if(accessStopped){ok=false;label='访问受阻，已暂停重试';}connected=ok;$('connection-status').textContent=label||(ok?'已同步':'正在重新连接…');$('connection-status').dataset.state=ok?'online':'offline';$('reconnect-button').hidden=ok;}
async function fetchJSON(path,options={}){
 if(accessStopped)throw accessStopped;
 const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),9000);
 try{const response=await fetch(path,{...options,cache:'no-store',signal:controller.signal,headers:{...(token?{Authorization:'Bearer '+token}:{}),...(options.body?{'Content-Type':'application/json'}:{}),...options.headers}});let data;const raw=await response.text();try{data=JSON.parse(raw);}catch{
 const blocked=[401,403,429].includes(response.status)||response.headers.get('cf-mitigated')==='challenge'||/Sorry, you have been blocked|Attention Required|cf-chl-/i.test(raw);
 const ray=response.headers.get('cf-ray')||raw.match(/Cloudflare Ray ID[^\n]{0,160}?([a-f0-9]{16})/i)?.[1];
 const e=new Error(blocked?'访问被网站安全防护拦截，已暂停自动重试。请将此提示截图反馈。'+(ray?' 诊断编号：'+ray:''):'服务器没有返回房间数据（HTTP '+response.status+'），已停止自动重试，请稍后手动重连。');
 e.status=response.status;e.noRetry=true;
 if(blocked){accessStopped=e;status(false);notice(e.message,true);}throw e;
 }if(!response.ok){const e=new Error(data.error||'操作未完成。');e.status=response.status;throw e;}return data;}catch(e){if(e.name==='AbortError')throw new Error('网络连接超时，正在重新同步。');throw e;}finally{clearTimeout(timeout);}
}
async function write(path,payload){const opts={method:'POST',body:JSON.stringify(payload)};try{return await fetchJSON(path,opts);}catch(e){if(e.noRetry||(e.status&&e.status!==503))throw e;return fetchJSON(path,opts);}}
function accept(data){if(room?.code===data.code&&data.version<room.version)return;room=data;const reconnected=!connected;status(true);if(reconnected)notice('连接已恢复，牌局已同步。');$('entrance').hidden=true;$('room-view').hidden=false;store.set('room',data.code);history.replaceState(null,'','/?room='+encodeURIComponent(data.code));render();}
function currentPlayer(){return room?.players.find(p=>p.id===room.turnPlayerId);}
function myPlayer(){return room?.players.find(p=>p.id===room.me);}
function controls(){
 $('create-button').disabled=busy||!token||!connected;$('join-button').disabled=busy||!token||!connected;
 if(!room)return;
 const host=room.hostId===room.me,mine=room.turnPlayerId===room.me,c=room.current,p=currentPlayer();
 const disabled=busy||!connected;
 let label='等待房主开始',action=null;
 if(room.phase==='lobby'&&host){label=room.players.length<2?'等待朋友加入':'开始游戏';if(room.players.length>=2)action='start';}
 if(room.phase==='playing'){if(mine){label=c?.awaiting?'完成，下一位':'抽一张牌';action=c?.awaiting?'finish':'draw';}else label='等待 '+(p?.name||'玩家');}
 if(room.phase==='paused')label='等待朋友重新加入';if(room.phase==='finished')label='牌已抽完，等待洗牌';if(room.phase==='closed')label='房间已结束';
 $('draw-button').textContent=busy?'正在同步…':label;$('draw-button').disabled=disabled||!action;$('draw-button').dataset.action=action||'';
 $('playing-card').disabled=disabled||action!=='draw';
 const canHold=c?.isFunction&&!c.isPublicRole&&c.ownerId===room.me&&c.awaiting&&room.phase==='playing';
 $('hold-button').hidden=!canHold;$('hold-button').disabled=disabled||c?.held||room.held.length>=2;
 $('hold-button').textContent=c?.held?'已保留到下方':room.held.length>=2?'保留区已满，先使用或弃牌':'保留这张功能牌';
 $('host-controls').hidden=!host||room.phase==='closed';$('advance-button').hidden=room.phase!=='playing';
 for(const id of ['shuffle-button','advance-button','close-room-button','leave-button'])$(id).disabled=disabled;
 for(const b of document.querySelectorAll('.held-actions button'))b.disabled=disabled||room.phase==='closed';
}
function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function renderPlayers(){const list=$('players');list.replaceChildren();for(let i=0;i<5;i++){const p=room.players[i],box=node('div',undefined,'player'+(p?.id===room.turnPlayerId&&room.phase==='playing'?' current-player':''));if(!p){box.classList.add('player-empty');box.textContent='等待加入';}else{box.append(node('div',[...p.name][0],'player-avatar'),node('h3',p.name+(p.id===room.me?'（你）':'')),node('p',p.id===room.hostId?'房主':p.online?'在线':'暂离',p.id===room.hostId?'player-tag':''),node('p','功能牌 '+p.heldCount+'/2'));if(p.id===room.publicRole?.ownerId)box.append(node('p','小姐 / 少爷','player-tag'));if(p.id===room.turnPlayerId&&room.phase==='playing')box.append(node('p','当前回合','player-tag'));}list.append(box);}}
function renderHeld(){const list=$('held-list');list.replaceChildren();for(let i=0;i<2;i++){const c=room.held[i],box=node('article',undefined,'held-card'+(c?'':' held-empty'));if(!c)box.append(node('p','空位 · 等待功能牌'));else{const actions=node('div',undefined,'held-actions');for(const [action,label] of [['use','使用并移除'],['discard','弃牌']]){const b=node('button',label);b.addEventListener('click',()=>command(action,{cardId:c.id}));actions.append(b);}box.append(node('h3',c.title),node('p',c.rule),actions);}list.append(box);}}
function renderPublicRole(){const c=room.publicRole;$('public-role').hidden=!c;if(!c)return;$('role-owner').textContent=c.ownerName+(c.ownerId===room.me?'（你）':'')+(c.ownerActive?'':' · 已离开');$('role-rule').textContent=c.rule;}
function render(){
 if(!room){controls();return;}
 const signature=JSON.stringify([room.version,room.players.map(p=>p.online)]);
 if(signature!==lastSignature){
 lastSignature=signature;renderPlayers();renderHeld();renderPublicRole();$('copy-code').textContent=room.code;
 const names={lobby:'等待开局',playing:'第 '+room.round+' 局',paused:'等待玩家',finished:'本局结束',closed:'房间已结束'};$('room-phase').textContent=names[room.phase];
 const p=currentPlayer(),mine=room.turnPlayerId===room.me,c=room.current;
 $('turn-title').textContent=room.phase==='lobby'?'等朋友，一起开局':room.phase==='playing'?(mine?'轮到你了':(p?.name||'玩家')+' 的回合'):room.phase==='paused'?'等待朋友回来':room.phase==='closed'?'本次夜局已结束':'这一副牌，玩完了';
 $('turn-note').textContent=room.phase==='lobby'?'已加入 '+room.players.length+'/5 人。按加入顺序轮流抽牌，房主点击开始。':room.phase==='playing'?(mine?(c?.awaiting?(c.isPublicRole?'身份牌已自动公开保留，完成后交给下一位。':'完成玩法后交给下一位；功能牌可先保留。'):'点击卡面或下方按钮抽牌，全员同步看到结果。'):'等对方完成回合后，自动轮到下一位。'):room.phase==='paused'?'至少需要两位玩家。把邀请链接发给朋友继续。':room.phase==='closed'?'点击离开，可以创建新的房间。':'房主可重新洗牌，再来一局。';
 $('remaining').textContent=room.remaining;$('drawn-count').textContent=String(room.total-room.remaining).padStart(2,'0');$('progress-fill').style.width=((room.total-room.remaining)/room.total*100)+'%';
 $('playing-card').classList.toggle('revealed',!!c);if(c){$('card-title').textContent=c.title;$('card-rule').textContent=c.rule;$('card-result').textContent='';$('card-category').textContent=c.isPublicRole?'公开身份牌':c.isFunction?'功能牌':'游戏牌';$('card-suit').textContent=c.isFunction?'♦':'♠';$('card-players').textContent=c.ownerName+' 抽到';document.querySelector('.card-front').classList.toggle('long-title',c.title.length>12);$('playing-card').setAttribute('aria-label',c.title+'。'+c.rule);}else $('playing-card').setAttribute('aria-label','抽取一张游戏卡');
 $('draw-owner').textContent=c?c.ownerName+' 的牌':'同桌同步';$('stage-caption').textContent=c?.awaiting?'全员可见 · 等待本回合完成':'轮到的玩家点击抽牌';
 $('last-event').textContent=room.events.at(-1)?.message||'欢迎加入';$('announcement').textContent=room.events.at(-1)?.message||'';
 }
 controls();
}
async function refresh(){if(polling||!room||busy||accessStopped)return;polling=true;try{accept(await fetchJSON('/api/rooms/'+room.code));}catch(e){status(false,e.status===404?'房间已过期':'连接中断');notice(e.message,true);if(!accessStopped&&[401,403,404,410].includes(e.status)){showEntrance(e.message);}}finally{polling=false;controls();}}
function schedule(){clearTimeout(timer);timer=setTimeout(async()=>{if(!document.hidden)await refresh();schedule();},document.hidden?10000:1800);}
function showEntrance(message=''){room=null;lastSignature='';$('room-view').hidden=true;$('entrance').hidden=false;store.remove('room');history.replaceState(null,'','/');status(true,'已连接');notice(message);controls();}
async function enter(kind){lastActionError=null;if(busy||!token){lastActionError=new Error('正在连接或操作中，请稍后重试。');return;}const name=$('nickname').value.trim();if(!name||[...name].length>12){lastActionError=new Error('昵称需要 1–12 个字。');notice(lastActionError.message,true);$('nickname').focus();return;}const code=$('room-code-input').value.trim().toUpperCase();if(kind==='join'&&!/^[23456789A-HJ-NP-Z]{8}$/.test(code)){lastActionError=new Error('请输入正确的 8 位房间号。');notice(lastActionError.message,true);return;}busy=true;controls();notice('');try{const data=await write(kind==='create'?'/api/rooms':'/api/rooms/'+code+'/join',{name,requestId:crypto.randomUUID()});store.set('name',name);accept(data);if(!storageOK)notice('当前浏览器无法保存身份，建议在 Safari 或 Chrome 中打开后再加入。',true);}catch(e){lastActionError=e;notice(e.message,true);if(!e.status){status(false);}}finally{busy=false;controls();}}
async function command(action,extra={}){lastActionError=null;if(!room||busy){lastActionError=new Error('尚未加入房间或正在操作，请稍后重试。');return;}busy=true;controls();notice('');const code=room.code,payload={action,...extra,requestId:crypto.randomUUID(),roundId:room.roundId,turnId:room.turnId};try{const data=await write('/api/rooms/'+code+'/action',payload);if(data.left){showEntrance('已离开房间。');return;}accept(data);}catch(e){lastActionError=e;notice(e.message,true);if(!e.status)status(false);try{accept(await fetchJSON('/api/rooms/'+code));}catch{}}finally{busy=false;controls();}return room;}
function confirmAction(action,title,description){pendingConfirm=action;$('confirm-title').textContent=title;$('confirm-description').textContent=description;$('confirm-dialog').showModal();}
async function copy(text){try{await navigator.clipboard.writeText(text);notice('已复制，发给朋友就能加入。');}catch{$('invite-link').value=text;$('invite-dialog').showModal();$('invite-link').select();}}
$('create-button').addEventListener('click',()=>enter('create'));$('room-form').addEventListener('submit',e=>{e.preventDefault();enter('join');});
$('draw-button').addEventListener('click',()=>{const action=$('draw-button').dataset.action;if(action)command(action);});$('playing-card').addEventListener('click',()=>command('draw'));$('hold-button').addEventListener('click',()=>command('hold'));
$('shuffle-button').addEventListener('click',()=>confirmAction('reset','重新洗牌？','全房间的抽牌进度和每个人保留的功能牌都会清空，84 张牌重新回到牌库。'));
$('advance-button').addEventListener('click',()=>confirmAction('advance','结束当前回合？','未保留的功能牌会弃掉，并轮到下一位。适合当前玩家暂时离开时使用。'));
$('close-room-button').addEventListener('click',()=>confirmAction('close','结束这个房间？','所有玩家都会看到房间已结束，不能再继续抽牌。'));
$('leave-button').addEventListener('click',()=>confirmAction('leave','离开这个房间？','你的功能牌会弃掉。如果你是房主，将交给下一位玩家管理。'));
$('confirm-action').addEventListener('click',()=>{const a=pendingConfirm;pendingConfirm=null;$('confirm-dialog').close();if(a)command(a);});
$('copy-code').addEventListener('click',()=>room&&copy(room.code));$('invite-button').addEventListener('click',()=>room&&copy(location.origin+'/?room='+room.code));
$('help-button').addEventListener('click',()=>$('help-dialog').showModal());document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).close()));
$('reconnect-button').addEventListener('click',()=>{accessStopped=null;return room?refresh():boot();});document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();schedule();});window.addEventListener('online',()=>room?refresh():boot());
async function boot(){status(false,'正在连接…');controls();try{token=store.get('token')||'';if(!/^[a-f0-9]{64}$/.test(token)){token=(await fetchJSON('/api/session')).token;store.set('token',token);}else await fetchJSON('/api/session');status(true,'已连接');$('nickname').value=store.get('name')||'';const code=(new URLSearchParams(location.search).get('room')||store.get('room')||'').toUpperCase();if(code){$('room-code-input').value=code;if(/^[23456789A-HJ-NP-Z]{8}$/.test(code)){try{accept(await fetchJSON('/api/rooms/'+code));}catch(e){if([403,404,410].includes(e.status)){store.remove('room');notice(e.status===403?'填写昵称，加入朋友的房间。':e.message,e.status!==403);}else throw e;}}}controls();schedule();}catch(e){status(false,'连接未完成');notice(e.message,true);controls();}}
boot();
if(document.modelContext?.registerTool){
 const life=new AbortController();const object=x=>{if(!x||typeof x!=='object'||Array.isArray(x))throw new Error('输入必须是对象。');};
 const tools=[
 {name:'read_room_state',description:'Read the shared room and only this player’s held cards.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute(input){object(input);if(Object.keys(input).length)throw new Error('不接受参数。');return room;}},
 {name:'create_game_room',description:'Create and enter a five-player room with a nickname.',inputSchema:{type:'object',properties:{name:{type:'string'}},required:['name'],additionalProperties:false},async execute(input){object(input);if(typeof input.name!=='string'||Object.keys(input).some(k=>k!=='name'))throw new Error('昵称无效。');$('nickname').value=input.name;await enter('create');if(lastActionError)throw lastActionError;return room;}},
 {name:'join_game_room',description:'Join an existing room by its eight-character invitation code.',inputSchema:{type:'object',properties:{name:{type:'string'},code:{type:'string'}},required:['name','code'],additionalProperties:false},async execute(input){object(input);if(typeof input.name!=='string'||typeof input.code!=='string'||Object.keys(input).some(k=>!['name','code'].includes(k)))throw new Error('参数无效。');$('nickname').value=input.name;$('room-code-input').value=input.code;await enter('join');if(lastActionError)throw lastActionError;return room;}},
 {name:'perform_game_action',description:'Perform an authorized turn, held-card, or host action. Reset, close, advance and leave require confirm=true.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['start','draw','finish','hold','use','discard','reset','close','advance','leave']},cardId:{type:'integer'},confirm:{type:'boolean'}},required:['action'],additionalProperties:false},async execute(input){object(input);if(!['start','draw','finish','hold','use','discard','reset','close','advance','leave'].includes(input.action)||Object.keys(input).some(k=>!['action','cardId','confirm'].includes(k)))throw new Error('无效操作。');if(['reset','close','advance','leave'].includes(input.action)&&input.confirm!==true)throw new Error('需要明确确认。');if(['use','discard'].includes(input.action)&&!Number.isInteger(input.cardId))throw new Error('需要卡牌编号。');const result=await command(input.action,input.cardId?{cardId:input.cardId}:{});if(lastActionError)throw lastActionError;return result;}}
 ];for(const tool of tools){try{Promise.resolve(document.modelContext.registerTool(tool,{signal:life.signal})).catch(()=>{});}catch{}}window.addEventListener('pagehide',()=>life.abort(),{once:true});
}
