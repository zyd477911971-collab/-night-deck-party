import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { createHash, randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { GameError, newRoom, viewRoom, findMember, joinRoom, applyAction, randomInt } from './server/game.js';

const root = fileURLToPath(new URL('.', import.meta.url));
const rooms = new Map();
const limits = new Map();
const TTL = 24 * 60 * 60 * 1000;

const hash = (value) => createHash('sha256').update(value).digest('hex');
const json = (res, data, status = 200) => {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
};
const fail = (res, error) => error instanceof GameError ? json(res, { error: error.message }, error.status) : json(res, { error: '房间服务暂时不可用，请稍后重试。' }, 503);
const requestBody = async (req) => {
  let text = '';
  for await (const chunk of req) { text += chunk; if (text.length > 8192) throw new GameError('请求内容过长。', 413); }
  try { const value = JSON.parse(text || '{}'); if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(); return value; }
  catch { throw new GameError('请求内容不正确。'); }
};
const userFor = (req) => {
  const match = String(req.headers.authorization || '').match(/^Bearer ([a-f0-9]{64})$/);
  if (!match) throw new GameError('身份已失效，请重新打开网页。', 401);
  return hash(match[1]);
};
const checkLimit = (key, max, windowMs) => {
  const now = Date.now(); const bucket = Math.floor(now / windowMs); const fullKey = `${key}:${bucket}`;
  const hits = (limits.get(fullKey) || 0) + 1; limits.set(fullKey, hits);
  if (hits > max) throw new GameError('操作太快，请稍等一会儿再试。', 429);
};
const roomRow = (code) => {
  const row = rooms.get(code);
  if (!row || row.expiresAt < Date.now()) { rooms.delete(code); throw new GameError('房间不存在或已过期，请核对房间号。', 404); }
  return row;
};
const mutate = (code, change) => {
  const row = roomRow(code); const changed = change(row.payload);
  if (changed !== false) { row.version += 1; row.expiresAt = Date.now() + TTL; }
  return row;
};
const staticTypes = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

async function handle(req, res) {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (!url.pathname.startsWith('/api/')) {
      const filename = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
      if (!['index.html', 'app.js', 'style.css'].includes(filename)) { res.writeHead(404); return res.end('Not found'); }
      const data = await readFile(join(root, 'public', filename));
      res.writeHead(200, { 'Content-Type': staticTypes[extname(filename)], 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
      return res.end(data);
    }
    if (req.method === 'GET' && url.pathname === '/api/session') {
      return json(res, { token: randomBytes(32).toString('hex') });
    }
    const user = userFor(req);
    if (req.method === 'POST' && url.pathname === '/api/rooms') {
      checkLimit(`create:${user}`, 8, 3600000);
      const input = await requestBody(req);
      if (typeof input.requestId !== 'string' || !/^[a-zA-Z0-9-]{16,80}$/.test(input.requestId)) throw new GameError('请求编号无效。');
      const createKey = `${user}:${input.requestId}`;
      for (const row of rooms.values()) if (row.createKey === createKey && row.expiresAt > Date.now()) return json(res, viewRoom(row, user), 201);
      const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
      let code;
      for (let attempt = 0; attempt < 20; attempt++) { code = Array.from({ length: 8 }, () => chars[randomInt(chars.length)]).join(''); if (!rooms.has(code)) break; }
      const row = { code, version: 0, payload: newRoom(input.name, user), createKey, expiresAt: Date.now() + TTL };
      rooms.set(code, row); return json(res, viewRoom(row, user), 201);
    }
    const match = url.pathname.match(/^\/api\/rooms\/([23456789A-HJ-NP-Z]{8})(?:\/(join|action))?$/);
    if (!match) throw new GameError('没有这个页面。', 404);
    const [, code, operation] = match;
    if (req.method === 'GET' && !operation) {
      const row = roomRow(code); const player = findMember(row.payload, user); if (!player) throw new GameError('请填写昵称加入这个房间。', 403);
      if (Date.now() - player.lastSeen > 18000 && row.payload.phase !== 'closed') mutate(code, room => { const member = findMember(room, user); if (!member) throw new GameError('你已离开这个房间。', 403); member.lastSeen = Date.now(); });
      return json(res, viewRoom(roomRow(code), user));
    }
    if (req.method === 'POST' && operation === 'join') {
      checkLimit(`join:${user}`, 20, 60000); const input = await requestBody(req); const row = mutate(code, room => joinRoom(room, user, input.name)); return json(res, viewRoom(row, user));
    }
    if (req.method === 'POST' && operation === 'action') {
      checkLimit(`action:${user}`, 100, 60000); const input = await requestBody(req); const row = mutate(code, room => applyAction(room, user, input)); return json(res, input.action === 'leave' ? { left: true } : viewRoom(row, user));
    }
    throw new GameError('不支持这个操作。', 405);
  } catch (error) { console.error(error); fail(res, error); }
}

const port = Number(process.env.PORT || 10000);
createServer(handle).listen(port, '0.0.0.0', () => console.log(`Night Deck listening on ${port}`));
